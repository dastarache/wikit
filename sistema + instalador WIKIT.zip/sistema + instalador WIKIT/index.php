<?php

  header('Location: InstaladorWIKIT/index.html');

?>