<?php
    // Archivo de configuracion para la conexion de la bd;
    define('DB_HOST', 'localhost');
    define('DB_NAME', ''); //   BD
    define('DB_USER', 'root');
    define('DB_PASS', '');
    
    

?>