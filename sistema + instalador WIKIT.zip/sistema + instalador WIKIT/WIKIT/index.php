<?php

    header('Location: controller/controll.php?seccion=1');

?>