<?php
    $n_nombre = $_REQUEST['n_nombre'];
    $n_curso = $_REQUEST['n_curso'];
    $perfil = $_REQUEST['perfil'];
    // include class
    require('../assets/fpdf/fpdf.php');

    // create document
    $pdf = new FPDF();
    $pdf->AddPage();

    // config document
    $pdf->SetTitle('CERTIFICAD');
    $pdf->SetAuthor('WIKIT');
    $pdf->SetCreator('FPDF WIKIT');

    // add title
    $pdf->SetFont('Arial', 'B', 50);
    $pdf->Cell(0, 13, '     CERTIFICADO     ', 0, 1);
    $pdf->Ln();

    // add text
    $pdf->SetFont('Arial', '', 20);
    $pdf->MultiCell(0, 7, utf8_decode('Se certifica que: '.$n_nombre.''), 0, 1);
    $pdf->Ln();
    $pdf->MultiCell(0, 7, utf8_decode('ha completado satisfactoriamente el curso : '.$n_curso.''), 0, 1);
    $pdf->Ln();
    $pdf->MultiCell(0, 7, utf8_decode('otorgado por: WIKIT'), 0, 1);
    $pdf->Ln();

    // add image
    $pdf->Image('../assets/img/'.$perfil.'', null, null, 180);

    // output file
    $pdf->Output('', 'fpdf-complete.pdf');

?>